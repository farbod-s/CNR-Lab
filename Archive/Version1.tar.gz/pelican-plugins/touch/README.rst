Touch plugin
############

A simple plugin doing a touch on your generated files using the date metadata
from the content.

This helps, into other things, to have the web server gently manage the cache.
