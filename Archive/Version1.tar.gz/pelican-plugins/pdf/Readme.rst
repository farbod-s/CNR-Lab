-------------
PDF Generator
-------------

The PDF Generator plugin automatically exports RST articles and pages
as PDF files as part of the site-generation process. PDFs are saved to
output/pdf/
