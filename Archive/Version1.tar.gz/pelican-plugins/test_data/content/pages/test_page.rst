This is a test page
###################

:category: test

Just an image.

.. image:: |filename|/pictures/Fat_Cat.jpg
   :height: 450 px
   :width: 600 px
   :alt: alternate text

