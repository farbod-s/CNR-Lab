layout: post
title: Sample Link Post
date: 2010-12-03 10:20
description: Example and code for using link posts.
tags: [sample post, link post]
comments: true
link: http://mademistakes.com  
share: true

This theme supports **link posts**, made famous by John Gruber. To use, just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.